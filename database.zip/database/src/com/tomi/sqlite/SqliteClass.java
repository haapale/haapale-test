package com.tomi.sqlite;

//import java.lang.reflect.Array;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.ResultSet;  
import java.sql.Statement;  

public class SqliteClass{
	public static Connection base(String database){
		Connection connection = null;  
	     try 
	     {  
	         Class.forName("org.sqlite.JDBC");  
	         connection = DriverManager.getConnection("jdbc:sqlite:" + database);
	     }
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
	     return connection;
	}
	public static ResultSet data(Connection connection, String lause){
	     ResultSet resultSet = null;  
	     Statement statement = null;
         try
         {
	         statement = connection.createStatement();  
	         resultSet = statement  
	                 .executeQuery(lause);
	     } 
	     catch (Exception e) 
	     {  
	         e.printStackTrace();  
	     }
	     finally 
	     {  
	         try 
	         {  
	             //resultSet.close();  
	             //statement.close();
	             //connection.close();
	         } 
	         catch (Exception e) 
	         {  
	             e.printStackTrace();  
	         }  
	     }
         return resultSet;
	}
}