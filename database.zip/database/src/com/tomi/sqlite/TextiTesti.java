package com.tomi.sqlite;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.io.*;

public class TextiTesti extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	protected JTextField textField;
	protected JTextArea textArea;
	private final static String newline = "\n";

	public TextiTesti() {
		super(new GridBagLayout());
		textField = new JTextField(20);
		textField.addActionListener(this);
		textArea = new JTextArea(5, 20);
		textArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(textArea);
		// Add Components to this panel.
		GridBagConstraints c = new GridBagConstraints();
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.HORIZONTAL;
		add(textField, c);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		c.weighty = 1.0;
		add(scrollPane, c);
	}

	public void actionPerformed(ActionEvent evt) {
//		String text = textField.getText();
//		SqliteClass sql = new SqliteClass();
		String[] whole_html = new String[1000];
		int i = 0;
		int tuotecount = 0;
		float totalhinta = 0;
    	float totalremaining = 0;
    	float totalspeculative = 0;
    	try {
    		Connection con = SqliteClass.base("c:\\users\\toivotom\\sqlite\\database\\rc");
        	DataOutputStream fileStream = new DataOutputStream(new FileOutputStream("c:/users/toivotom/treeni/outti.html"));
        	//Time now = TimeNow();
            ResultSet res = SqliteClass.data(con, "select * from ostot");
            while(res.next()){
            	tuotecount ++;
            	String cellcolor = "#FFFFFF";
            	String namecellcolor = "#FFFFFF";
            	String fontcolor = "#000000";
          	    String name = res.getString("Tuote");
                float price = res.getFloat("Hinta");
                totalhinta += price;
                float remaining = res.getFloat("Remaining");
                totalremaining += remaining;
                float speculative = res.getFloat("Speculative");
                totalspeculative += speculative;
                String info = "";
                if (res.getString("Info") != null){
                	info = res.getString("Info");
                }
                if (speculative == 0.0){
                	cellcolor = "#999999";
                	namecellcolor = cellcolor;
                    if (remaining > 0){
                    	fontcolor = "#FF0000";
                    }else{
                    	fontcolor = "#33FF33";
                    }
                }else if(speculative > 0 && speculative >= remaining){
                	cellcolor = "#33CC33";
                }else if(speculative > 0 && speculative < remaining){
                	cellcolor = "#FF0000";
                }
                String text = name + "\t" + price + "\t" + remaining + "\t" + speculative + "\t" + info;
          	    whole_html[i] = "<tr><td bgcolor=" + namecellcolor + ">" + name + "</td><td bgcolor=" + cellcolor + "> <span style='text-shadow: 1px 1px 1px #000000;'><font color=" + fontcolor +">" + price + "</font></span></td><td bgcolor=" + cellcolor + "><span style='text-shadow: 1px 1px 1px #000000;'> <font color=" + fontcolor +">" + remaining + "</font></span></td><td bgcolor=" + cellcolor + "> <span style='text-shadow: 1px 1px 1px #000000;'><font color=" + fontcolor +">" + speculative + "</font></span></td><td>" + info + "</td></tr>\n";
          	    textArea.append(text + newline);
          	    textField.selectAll();
            // Make sure the new text is visible, even if there
    		// was a selection in the text area.
          	    textArea.setCaretPosition(textArea.getDocument().getLength());
          	    i++;
            }
      	    res.close();  
            con.close();
            String header = "<html><body bgcolor = #FFFFFF><table cellspacing=2px border=1px align=center><tr><th>Tuote (" + tuotecount + ")</th><th>Hinta (" + totalhinta + ")</th><th>Remaining (" + totalremaining + ")</th><th>Spekulatiivinen (" + totalspeculative + ")</th></tr>\n";
        	String footer = "\n</table></body></html>";
            fileStream.writeBytes(header);
            for ( i=0; i < whole_html.length-1; i++){
            	if ( whole_html[i] != null){
            	    String html = whole_html[i];
                    fileStream.writeBytes(html);
            	}
            }
            fileStream.writeBytes(footer);
            fileStream.close();

        }
        catch (Exception e){
        	e.printStackTrace();
        }
        finally{
        	System.out.println("Ohi on.");
        }
	}

	private static void createAndShowGUI() {
		// Create and set up the window.
		JFrame frame = new JFrame("TextDemo");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Add contents to the window.
		frame.add(new TextiTesti());
		// Display the window.
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		// Schedule a job for the event dispatch thread:
		// creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGUI();
			}
		});
	}
}