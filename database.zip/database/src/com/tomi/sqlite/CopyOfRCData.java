package com.tomi.sqlite;
//import java.lang.reflect.Array;
import java.sql.Connection;  
//import java.sql.DriverManager;  
import java.sql.ResultSet;  
//import java.sql.Statement;  

public class CopyOfRCData{
	public static void main(String args[]){
		SqliteClass db = new SqliteClass();
		IkkunaClass window = new IkkunaClass();
		Connection conn = SqliteClass.base("c:\\users\\toivotom\\sqlite\\database\\rc");
		ResultSet res = SqliteClass.data(conn,  "SELECT * FROM ostot");
		System.out.println(res);
		window.ikkunaMetodi();
		
	}
}